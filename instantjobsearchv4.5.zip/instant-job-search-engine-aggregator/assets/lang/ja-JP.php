<?php
// HTML LANG reference http://www.w3schools.com/tags/ref_language_codes.asp
$language_code = 'ja';

$sitename = "Jobs Aggregator";
$siteslogan = "All-in-one Job Search Engine";
$sitedescription = $sitename .' is an automatic job search engine and aggregator thats find all the latest jobs on all major job sites. Job search made simple with '.$sitename;
$sitekeywords = "job board, jobs, job search engine, find jobs, careers, employment, job listings, resume builder, resume post, jobboot,job aggregator,rss jobs";

// DEFAULT CATEGORIES: You can change the default categories for your Niche below.
$categories = "IT,電気通信,アート,デザイン,芸能,エンジニアリング,カスタマーサービス,コールセンター,コンサルタント,スポーツ,レジャー,ファッション,テキスタイル,マーケティング,広報,メディア,広告代理店,レストラン,食品産業,一般事務,秘書,アシスタント,不動産業,人材,人事関連,保険,公営企業,公務員,出版,印刷業,医療関係,品質保証,営業,セールス,建築,建設業,慈善団体,NPO,教育,レッスン,木材,製紙,家具,法執行機関,警備,法律,税務,海運,造船,船舶,理美容,エステほか,石油,ガス,鉱業,社会福祉,科学,研究,開発,管理職,重役幹部,経理,会計監査,翻訳,通訳,自動車産業,航空宇宙科学,防衛,製造,メンテナンス,観光,旅行,サービス業,販売店,卸売業,購買,買付,輸送,物流,農業,林業,漁業,銀行業務,金融サービス,鋼鉄,金属,電子工学,ロボット工学,食品加工";

// DEFAULT LOCATIONS: You can change the default locations below.
$locations = "中国地方,中部地方,九州地方,北海道,四国地方,東北地方,関東地方,関西地方";


// CAROUSEL SLIDER
$slide1_title = "All-in-one Job search";
$slide1_description = "Search multiple job sites at once. ";
$slide2_title = "Supported Job Sites";
$slide2_description = "One search to find all job postings on Indeed, CareerJet, SimplyHired, MonsterBoard and more.";
$slide3_title = "Job Aggregator";
$slide3_description = "Browse jobs by Category or Location or Search Jobs in Realtime.";

// CONTACT & ABOUT
$contact_company_name = "Jobs Aggregator HQ";
$contact_email = "info@jobsaggregator.com";
$contact_address_street = "872 Lombard street";
$contact_address_city = "San Francisco, CA 90234";
$contact_tel = "+ 2 (533) 765-831";

$about_text= "<p>Jobs Aggregator is an all-in-one Job Search Engine for Every Country.</p><p>Find the latest Job listings posted on job banks, job search engine sites and job directories.</p>";

$privacy_text= "<p> Privacy description here ! </p>";

$term_of_use_text= "<p> Term of Use description here ! </p>";

// General string

$strings['SUFFIX_JOBS'] = '%s Jobs';
$strings['JOBS'] = 'Jobs';
$strings['PREFIX_IN'] = ' in %s';
$strings['CLOSE'] = 'Close';
$strings['SEARCH'] = 'SEARCH';
$strings['START_NEW_SEARCH'] = 'Start new search';
$strings['LOADING'] = 'Loading';
$strings['PLACEHOLDER_SEARCH'] = 'Search';
$strings['PLACEHOLDER_LOCATION'] = 'Location';
$strings['BTN_LEARN_MORE'] = 'Learn More';
$strings['BTN_JOB_AGGREGATOR'] = 'Job Aggregator';
$strings['BTN_BROWSE_JOBS'] = 'Browse Job';
$strings['BTN_FIND_YOUR_JOB'] = 'Find your job';

$strings['HEADING_SEARCH_JOBS'] = 'Search Jobs';
$strings['LEADING_FIND_JOBS_BY_KEYWORD_OR_LOCATION'] = 'Find jobs by keyword or location';
$strings['TEXT_SEARCH_ON'] = 'Search on popular job posting sites at once with just once search or browse jobs by category or location below.';
$strings['TEXT_NO_RESULT'] = '<p class="no-jobs">No job listings match your search %s on %s</p>';
$strings['PUBLISHED_ON'] = 'Published on';

$strings['HEADING_CATEGORIES'] = 'Categories';
$strings['DESCRIPTION_CATEGORIES'] = 'Search multiple job sites at once. One search to find all job postings at %s.';

$strings['HEADING_LOCATIONS'] = 'Locations';
$strings['DESCRIPTION_LOCATIONS'] = 'Remember to "think local" when you want to find a job in a specific location. Your job search should focus on local job search resources';

$strings['SEARCHRESULT_JOBS_FOR_TODAY_JOB'] = '%s Jobs for today';
$strings['SEARCHRESULT_JOBS_FOR_TODAY_LOC'] = 'Jobs for today in %s';
$strings['SEARCHRESULT_JOBS_FOR_TODAY_ALL'] = '%s Jobs for today in %s';
$strings['SEARCHRESULT_DESCRIPTION'] = 'View Latest posted %s job listings on job banks, job search engine sites and job directories.';

$strings['TAB_ALL'] = 'All';

$strings['HEADING_NAVIGATION'] = 'Navigation';
$strings['HEADING_JOBSITES_ADDED'] = 'Jobsites added';
$strings['HEADING_STAY_IN_TOUCH'] = 'Stay in touch';
$strings['TEXT_SOCIAL'] = 'Share this %s jobs with your friends on your favorite social network';
$strings['HEADING_OUR_OFFICE'] = 'Our office';

$strings['MENU_HOME'] = 'Home';
$strings['MENU_SEARCH'] = 'Search';
$strings['MENU_BROWSE'] = 'Browse';
$strings['MENU_CATEGORIES'] = 'Categories';
$strings['MENU_LOCATIONS'] = 'Locations';
$strings['MENU_LATEST'] = 'Lastest';
$strings['MENU_LANGUAGE'] = 'Language';
$strings['MENU_DOWNLOAD'] = 'Download';

$strings['MENU_ABOUT_US'] = 'About Us';
$strings['MENU_PRIVACY']  = 'Privacy';
$strings['MENU_TERM_OF_USE'] = 'Term of Use';

$strings['POWERED_BY'] = 'Powered By';

$strings['JOB_RESULTS'] = 'jobresults';