<?php
$strings['VI-VN'] = 'Vietnam';
$strings['NL-NL'] = 'Netherlands';
$strings['EN-US'] = 'United States';
$strings['UK-UK'] = 'United Kingdom';
$strings['TR-TR'] = 'Turkey';
$strings['CS-CZ'] = 'Czech Republic';
$strings['DA-DK'] = 'Denmark';
$strings['DE-AT'] = 'Austria';
$strings['DE-CH'] = 'Switzerland';
$strings['DE-DE'] = 'Germany';
$strings['EN-AE'] = 'United Arab Emirates';
$strings['EN-AU'] = 'Australia';
$strings['EN-CA'] = 'Canada';
$strings['EN-CN'] = 'China';
$strings['EN-HK'] = 'Hong Kong';
$strings['EN-IE'] = 'Ireland';
$strings['EN-IN'] = 'India';
$strings['EN-MY'] = 'Malaysia';
$strings['EN-NZ'] = 'New Zealand';
$strings['EN-OM'] = 'Oman';
$strings['EN-PH'] = 'Philippines';
$strings['EN-PK'] = 'Pakistan';
$strings['EN-QA'] = 'Qatar';
$strings['EN-SG'] = 'Singapore';
$strings['EN-GB'] = 'United Kingdom';
$strings['EN-ZA'] = 'South Africa';
$strings['EN-TW'] = 'Taiwan';
$strings['EN-VN'] = 'Vietnam';
$strings['ES-AR'] = 'Argentina';
$strings['ES-BO'] = 'Bolivia';
$strings['ES-CL'] = 'Chile';
$strings['ES-CR'] = 'Costa Rica';
$strings['ES-DO'] = 'Dominican Republic';
$strings['ES-EC'] = 'Ecuador';
$strings['ES-ES'] = 'Spain';
$strings['ES-GT'] = 'Guatemala';
$strings['ES-MX'] = 'Mexico';
$strings['ES-PA'] = 'Panama';
$strings['ES-PE'] = 'Peru';
$strings['ES-PR'] = 'Puerto Rico';
$strings['ES-PY'] = 'Paraguay';
$strings['ES-UY'] = 'Uruguay';
$strings['ES-VE'] = 'Venezuela';
$strings['FI-FI'] = 'Finland';
$strings['FR-CA'] = 'Canada';
$strings['FR-BE'] = 'Belgium';
$strings['FR-CH'] = 'Switzerland';
$strings['FR-FR'] = 'France';
$strings['FR-LU'] = 'Luxembourg';
$strings['FR-MA'] = 'Morocco';
$strings['HU-HU'] = 'Hungary';
$strings['IT-IT'] = 'Italy';
$strings['JA-JP'] = 'Japan';
$strings['KO-KR'] = 'Korea';
$strings['NL-BE'] = 'Belgium';
$strings['NO-NO'] = 'Norway';
$strings['PL-PL'] = 'Poland';
$strings['PT-PT'] = 'Portugal';
$strings['PT-BR'] = 'Brazil';
$strings['RU-RU'] = 'Russia';
$strings['RU-UA'] = 'Ukraine';
$strings['SV-SE'] = 'Sweden';
$strings['SK-SK'] = 'Slovakia';
$strings['UK-UA'] = 'Ukraine';
$strings['ZH-CN'] = 'China';

