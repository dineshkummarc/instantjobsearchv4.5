Thank you for purchasing the Instant Job Search Engine Aggregator PHP Script v4.5!

To install the software, simply click on the documentation help file in the documentation folder and it will open up in your browser.

Should you have any queries outside of the scope of the help documentation don't hesitate to contact us at: https://www.mediageni.com

Kind regards,
MediaGeni team